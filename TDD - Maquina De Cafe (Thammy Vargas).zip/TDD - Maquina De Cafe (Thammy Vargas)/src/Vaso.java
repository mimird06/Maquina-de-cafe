import java.util.Scanner;

public class Vaso {
    private int capacidad;

    public Vaso(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getCapacidad() {
        return capacidad;
    }
}
